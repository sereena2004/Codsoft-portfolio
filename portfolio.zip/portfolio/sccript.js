document.addEventListener('DOMContentLoaded', function() {
    
    var toggleBtn = document.querySelector(".togglebtn");
    var navLinks = document.querySelector(".navlinks");
    var cvBtn = document.getElementById('cvBtn');
    var cvSection = document.getElementById('cvSection');

    toggleBtn.addEventListener("click", function() {
        toggleBtn.classList.toggle("click");
        navLinks.classList.toggle("open");
    });

   
    cvBtn.addEventListener('click', function(event) {
        event.preventDefault(); 
        cvSection.classList.toggle('active');
    });
});
